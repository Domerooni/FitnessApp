import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.EnumMap;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

// Bonus points: Create an icon (or find a public domain icon. Keep in mind federal Copyright law and TAMU's plagiarism policy and add it to the home screen window.
public class MainWindow implements ActionListener {
  
  private final JFrame mainFrame = new JFrame(Config.APPLICATIONNAME);
  private final JDialog selectWorkout = new JDialog(mainFrame, "Select Workout");
  private JComboBox<String> cboType, cboGoal;
  private JSpinner spnDuration;
  private final Workouts workouts;
  private final EnumMap<Config.MuscleGroup, ArrayList<Config.Muscle>> muscleGroups;
  private final JButton UpperBody = new JButton();
  private final JButton LowerBody = new JButton();
  private final JButton WholeBody = new JButton();
  
  MainWindow(Workouts workouts, EnumMap<Config.MuscleGroup, ArrayList<Config.Muscle>> muscleGroups) {
    // Code goes here.
	  this.workouts = workouts;
	  this.muscleGroups = muscleGroups;
	  // MainWindow should call launchHomeScreen() as the very last thing
	  launchHomeScreen();
  }
  
  private void launchHomeScreen() {
    // Code goes here.
	//------------------------------------------------------------
	  mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	  mainFrame.setSize(600,400);
	  mainFrame.setVisible(true);
	  //----------------------------------------------------------
	  //JButton UpperBody = new JButton();
	  //JButton LowerBody = new JButton();
	  //JButton WholeBody = new JButton();
	  //----------------------------------------------------------
	  // THE ICON I MADE FOR GLEN
	  ImageIcon myIcon = new ImageIcon("C:/Users/Dominick/git/Project-CSCE314/javafit/Glenjamin/Glenjamin2.png");
	  Image image = myIcon.getImage();
	  Image newimg = image.getScaledInstance(300, 300, java.awt.Image.SCALE_SMOOTH);
	  ImageIcon mine = new ImageIcon(newimg);
	  JLabel myLabel = new JLabel(mine);
	  myLabel.setBounds(000,300,600,60);
	  //-----------------------------------------------------------
	  UpperBody.setText("UpperBody");
	  LowerBody.setText("LowerBody");
	  WholeBody.setText("WholeBody");
	  
	  UpperBody.setBounds(000,000,600,110);
	  LowerBody.setBounds(000,120,600,110);
	  WholeBody.setBounds(000,240,600,120);
	  
	  UpperBody.addActionListener(this);
	  LowerBody.addActionListener(this);
	  WholeBody.addActionListener(this);
	  
	  mainFrame.add(UpperBody);
	  mainFrame.add(LowerBody);
	  mainFrame.add(WholeBody);
	  mainFrame.add(myLabel);
	  //----------------------------------------------------------
  }
  
  // This is the method your actionlistener should call. It should create and display a WorkoutsPanel.
  private void showWorkouts(ArrayList<Config.Muscle> muscles) {
  // Code goes here.
	  mainFrame.remove(UpperBody);
	  mainFrame.remove(LowerBody);
	  mainFrame.remove(WholeBody);
	  //mainFrame.remove(myLabel);
	  mainFrame.setVisible(false);
	  mainFrame.setVisible(true);
	  WorkoutsPanel WP = new WorkoutsPanel(muscles, workouts);
	  
	  WP.setBounds(000,000,500,300);
	  mainFrame.add(WP);
  }

@Override
public void actionPerformed(ActionEvent arg0) {
	// TODO Auto-generated method stub
	JButton b = null;
	b = (JButton)arg0.getSource(); // button = what was pressed
	String buttonName = b.getText();
	
	if(buttonName == "UpperBody") {
		showWorkouts(muscleGroups.get(Config.MuscleGroup.UPPERBODY));
	}
	else if(buttonName == "LowerBody") {
		showWorkouts(muscleGroups.get(Config.MuscleGroup.LOWERBODY));
	}
	else if(buttonName == "WholeBody") {
		showWorkouts(muscleGroups.get(Config.MuscleGroup.WHOLEBODY));
	}
}
}
